﻿using LoanApplication.Entities;
using Microsoft.AspNetCore.Identity;

namespace LoanApplication.Interface
{
    public interface IPasswordHelper
    {
        string HashPassword(string password);

        bool VerifyPassword(string hashedPassword, string providedPassword);
    }
}
