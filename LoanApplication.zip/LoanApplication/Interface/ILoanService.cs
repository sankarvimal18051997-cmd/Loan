﻿using LoanApplication.DTO;

namespace LoanApplication.Interface
{
    public interface ILoanService
    {
        EmiCalculationResponseDto CalculateEMI(EmiCalculationRequestDto request);
    }
}
