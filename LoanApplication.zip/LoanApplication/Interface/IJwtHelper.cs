﻿using LoanApplication.Entities;

namespace LoanApplication.Interface
{
    public interface IJwtHelper
    {
        string GenerateToken(Users user);
    }
}
