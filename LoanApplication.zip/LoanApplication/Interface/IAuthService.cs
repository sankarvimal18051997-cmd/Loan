﻿using LoanApplication.DTO;
using LoanApplication.Entities;

namespace LoanApplication.Interface
{
    public interface IAuthService
    {
        Task<List<Users>> GetUsersAsync();
        Task<Users?> RegisterAsync(UserRequestDto dto);
        Task<string?> LoginAsync(LoginRequestDto dto);
    }
}
