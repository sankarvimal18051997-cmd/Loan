﻿using LoanApplication.DTO;
using LoanApplication.Entities;

namespace LoanApplication.Interface
{
    public interface IAuthRepository
    {
        Task<List<Users>> GetAllUsersAsync();
        Task<Users?> GetByUsernameOrEmailAsync(string usernameOrEmail);
        Task<Users> CreateUserAsync(Users user);

    }
}
