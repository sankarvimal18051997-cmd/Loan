﻿using System.ComponentModel.DataAnnotations;

namespace LoanApplication.DTO
{
    public class UserRequestDto
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Email { get; set; }
    }
}
