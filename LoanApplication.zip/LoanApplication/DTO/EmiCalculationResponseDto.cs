﻿namespace LoanApplication.DTO
{
    public class EmiCalculationResponseDto
    {
        public decimal MonthlyEmi { get; set; }
        public decimal TotalInterest { get; set; }
        public decimal TotalPayment { get; set; }
        public List<AmortizationDto> Schedule { get; set; }
    }
}
