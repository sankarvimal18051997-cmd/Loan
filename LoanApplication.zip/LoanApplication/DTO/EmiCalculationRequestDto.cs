﻿namespace LoanApplication.DTO
{
    public class EmiCalculationRequestDto
    {
        public decimal Principal { get; set; }
        public decimal InterestRate { get; set; } // Annual %
        public int TenureMonths { get; set; }
    }
}
