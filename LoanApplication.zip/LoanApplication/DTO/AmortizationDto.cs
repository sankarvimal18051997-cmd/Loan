﻿namespace LoanApplication.DTO
{
    public class AmortizationDto
    {
        public int Month { get; set; }
        public decimal OpeningBalance { get; set; }
        public decimal EmiAmount { get; set; }
        public decimal PrincipalComponent { get; set; }
        public decimal InterestComponent { get; set; }
        public decimal ClosingBalance { get; set; }
    }
}
