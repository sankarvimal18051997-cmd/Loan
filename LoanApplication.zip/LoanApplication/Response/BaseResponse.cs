﻿namespace LoanApplication.Response
{
    public class BaseResponse<T>
    {
        public string Message { get; set; }
        public string Status { get; set; }
        public int code { get; set; }

        public T? Data { get; set; }

    }
}
