﻿using LoanApplication.DTO;
using LoanApplication.Entities;
using LoanApplication.Interface;

namespace LoanApplication.Services
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository _repo;
        private readonly IPasswordHelper _passwordHelper;
        private readonly IJwtHelper _jwtHelper;

        public AuthService(
            IAuthRepository repo,
            IPasswordHelper passwordHelper,
            IJwtHelper jwtHelper)
        {
            _repo = repo;
            _passwordHelper = passwordHelper;
            _jwtHelper = jwtHelper;
        }

        public async Task<List<Users>> GetUsersAsync()
        {
            return await _repo.GetAllUsersAsync();
        }

        public async Task<Users?> RegisterAsync(UserRequestDto dto)
        {
            var existing = await _repo.GetByUsernameOrEmailAsync(dto.UserName);

            if (existing != null)
                return null;

            var hashedPassword = _passwordHelper.HashPassword(dto.Password);

            var user = new Users
            {
                username = dto.UserName,
                email = dto.Email,
                password = hashedPassword,
                CreatedAt = DateTime.Now,
                IsActive = true
            };

            return await _repo.CreateUserAsync(user);
        }

        public async Task<string?> LoginAsync(LoginRequestDto dto)
        {
            var user = await _repo.GetByUsernameOrEmailAsync(dto.UsernameOrEmail);

            if (user == null)
                return null;

            var valid = _passwordHelper.VerifyPassword(user.password, dto.Password);

            if (!valid)
                return null;

            return _jwtHelper.GenerateToken(user);
        }
    }
}
