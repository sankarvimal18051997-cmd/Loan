﻿using LoanApplication.DTO;
using LoanApplication.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LoanApplication.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        [HttpPost("calculate")]
        public BaseResponse<EmiCalculationResponseDto> CalculateEMI(EmiCalculationRequestDto request)
        {
            try
            {
                decimal P = request.Principal;
                decimal annualRate = request.InterestRate;
                int N = request.TenureMonths;

                decimal monthlyRate = annualRate / 12 / 100;

                // EMI Formula
                decimal emi = P * monthlyRate *
                             (decimal)Math.Pow((double)(1 + monthlyRate), N) /
                             ((decimal)Math.Pow((double)(1 + monthlyRate), N) - 1);

                emi = Math.Round(emi, 2);

                decimal balance = P;
                decimal totalInterest = 0;

                var schedule = new List<AmortizationDto>();

                for (int month = 1; month <= N; month++)
                {
                    decimal interest = Math.Round(balance * monthlyRate, 2);
                    decimal principal = Math.Round(emi - interest, 2);
                    decimal closingBalance = Math.Round(balance - principal, 2);

                    totalInterest += interest;

                    schedule.Add(new AmortizationDto
                    {
                        Month = month,
                        OpeningBalance = balance,
                        EmiAmount = emi,
                        InterestComponent = interest,
                        PrincipalComponent = principal,
                        ClosingBalance = closingBalance
                    });

                    balance = closingBalance;
                }

                var response = new EmiCalculationResponseDto
                {
                    MonthlyEmi = emi,
                    TotalInterest = Math.Round(totalInterest, 2),
                    TotalPayment = Math.Round(P + totalInterest, 2),
                    Schedule = schedule
                };

                return new BaseResponse<EmiCalculationResponseDto>
                {
                    code = 200,
                    Status = "Success",
                    Message = "EMI calculated successfully",
                    Data = response
                };
            }
            catch (Exception)
            {
                return new BaseResponse<EmiCalculationResponseDto>
                {
                    code = 500,
                    Status = "Error",
                    Message = "EMI calculation failed",
                    Data = null
                };
            }
        }
    }
}
