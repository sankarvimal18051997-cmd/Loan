﻿using LoanApplication.DTO;
using LoanApplication.Entities;
using LoanApplication.Interface;
using LoanApplication.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net.NetworkInformation;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LoanApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
         private readonly IAuthService _service;

        public AuthController(IAuthService service)
        {
            _service = service;
        }


        [HttpGet]
            public async Task<IActionResult> GetUsers()
            {
                var users = await _service.GetUsersAsync();

                if (users == null || users.Count == 0)
                {
                    return NotFound(new BaseResponse<List<Users>>
                    {
                        code = 404,
                        Status = "Failed",
                        Message = "No users found",
                        Data = null
                    });
                }

                return Ok(new BaseResponse<List<Users>>
                {
                    code = 200,
                    Status = "Success",
                    Message = "Users retrieved successfully",
                    Data = users
                });
            }

            [HttpPost("register")]
            public async Task<IActionResult> Register(UserRequestDto dto)
            {
                var user = await _service.RegisterAsync(dto);

                if (user == null)
                {
                    return Conflict(new BaseResponse<Users>
                    {
                        code = 409,
                        Status = "Failed",
                        Message = "User already exists",
                        Data = null
                    });
                }

                return Ok(new BaseResponse<Users>
                {
                    code = 200,
                    Status = "Success",
                    Message = "User created successfully",
                    Data = user
                });
            }

            [HttpPost("login")]
            public async Task<IActionResult> Login(LoginRequestDto dto)
            {
                var token = await _service.LoginAsync(dto);

                if (token == null)
                {
                    return Unauthorized(new BaseResponse<object>
                    {
                        code = 401,
                        Status = "Failed",
                        Message = "Invalid credentials",
                        Data = null
                    });
                }

                return Ok(new BaseResponse<object>
                {
                    code = 200,
                    Status = "Success",
                    Message = "Login successful",
                    Data = new { Token = token }
                });
            }
        }
    }
