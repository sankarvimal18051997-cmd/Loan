﻿using LoanApplication.Data;
using LoanApplication.Entities;
using LoanApplication.Interface;
using Microsoft.EntityFrameworkCore;

namespace LoanApplication.Repository
{
    public class AuthRepository: IAuthRepository
    {
        private readonly AppDbContext _db;

        public AuthRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<List<Users>> GetAllUsersAsync()
        {
            return await _db.Users.ToListAsync();
        }

        public async Task<Users?> GetByUsernameOrEmailAsync(string usernameOrEmail)
        {
            return await _db.Users.FirstOrDefaultAsync(x =>
                x.username == usernameOrEmail ||
                x.email == usernameOrEmail);
        }

        public async Task<Users> CreateUserAsync(Users user)
        {
            await _db.Users.AddAsync(user);
            await _db.SaveChangesAsync();
            return user;
        }
    }
}
