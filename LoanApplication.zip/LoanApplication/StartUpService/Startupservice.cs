﻿using LoanApplication.Interface;
using LoanApplication.JWTHelper;
using LoanApplication.Repository;

namespace LoanApplication.StartUpService
{
    public static class Startupservice
    {
        public static void AddLoadService(this IServiceCollection services)
        {
            services.AddScoped<IAuthRepository, AuthRepository>();
            services.AddScoped<IAuthService, Services.AuthService>();
            services.AddScoped<ILoanService, Services.LoanService>();

            services.AddScoped<IJwtHelper, JwtHelper>();
           services.AddScoped<IPasswordHelper, PasswordHelper.PasswordHelper>();

        }
    }
}
